//package com.tweetapp.application.repo;
//
//import org.springframework.data.mongodb.repository.MongoRepository;
//
//import com.tweetapp.application.model.Role;
//
//public interface RoleRepo extends MongoRepository<Role, Long>{
//	Role findByName(String name);
//}
